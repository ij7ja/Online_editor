import { createServer } from "node:http";
import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const dataDir = join(__dirname, "database");
const dbPath = join(dataDir, "users.db");
const port = Number(process.env.API_PORT || 5173);

mkdirSync(dataDir, { recursive: true });

const db = new DatabaseSync(dbPath);

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    salt TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`);

const findUser = db.prepare(
  "SELECT id, username, password_hash, salt FROM users WHERE username = ?",
);
const createUser = db.prepare(
  "INSERT INTO users (username, password_hash, salt) VALUES (?, ?, ?)",
);
const createSessionRecord = db.prepare(
  "INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)",
);
const findSession = db.prepare(`
  SELECT users.id, users.username
  FROM sessions
  JOIN users ON users.id = sessions.user_id
  WHERE sessions.token = ? AND sessions.expires_at > CURRENT_TIMESTAMP
`);
const deleteSession = db.prepare("DELETE FROM sessions WHERE token = ?");

function normalizeUsername(username) {
  return String(username || "").trim().toLowerCase();
}

function hashPassword(password, salt = randomBytes(16).toString("hex")) {
  const passwordHash = scryptSync(password, salt, 64).toString("hex");
  return { passwordHash, salt };
}

function isPasswordValid(password, user) {
  const { passwordHash } = hashPassword(password, user.salt);
  const storedHash = Buffer.from(user.password_hash, "hex");
  const enteredHash = Buffer.from(passwordHash, "hex");

  return (
    storedHash.length === enteredHash.length &&
    timingSafeEqual(storedHash, enteredHash)
  );
}

function createSession(userId) {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
    .toISOString()
    .slice(0, 19)
    .replace("T", " ");
  createSessionRecord.run(token, userId, expiresAt);
  return token;
}

function getBearerToken(request) {
  const header = request.headers.authorization || "";
  return header.startsWith("Bearer ") ? header.slice(7) : "";
}

async function readJsonBody(request) {
  let body = "";

  for await (const chunk of request) {
    body += chunk;

    if (body.length > 1_000_000) {
      throw new Error("Request body is too large.");
    }
  }

  return body ? JSON.parse(body) : {};
}

function sendJson(response, statusCode, payload) {
  response.writeHead(statusCode, {
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Origin": "*",
    "Content-Type": "application/json",
  });
  response.end(JSON.stringify(payload));
}

function validateCredentials(username, password) {
  if (username.length < 3) {
    return "Username must be at least 3 characters.";
  }

  if (String(password || "").length < 6) {
    return "Password must be at least 6 characters.";
  }

  return "";
}

async function handleRegister(request, response) {
  const body = await readJsonBody(request);
  const username = normalizeUsername(body.username);
  const password = String(body.password || "");
  const validationError = validateCredentials(username, password);

  if (validationError) {
    sendJson(response, 400, { message: validationError });
    return;
  }

  if (findUser.get(username)) {
    sendJson(response, 409, { message: "Username already exists." });
    return;
  }

  const { passwordHash, salt } = hashPassword(password);
  const result = createUser.run(username, passwordHash, salt);
  const token = createSession(result.lastInsertRowid);

  sendJson(response, 201, {
    message: "Account created.",
    token,
    user: { id: result.lastInsertRowid, username },
  });
}

async function handleLogin(request, response) {
  const body = await readJsonBody(request);
  const username = normalizeUsername(body.username);
  const password = String(body.password || "");
  const user = findUser.get(username);

  if (!user || !isPasswordValid(password, user)) {
    sendJson(response, 401, { message: "Invalid username or password." });
    return;
  }

  const token = createSession(user.id);

  sendJson(response, 200, {
    message: "Login successful.",
    token,
    user: { id: user.id, username: user.username },
  });
}

function handleMe(request, response) {
  const token = getBearerToken(request);
  const user = token ? findSession.get(token) : null;

  if (!user) {
    sendJson(response, 401, { message: "Not logged in." });
    return;
  }

  sendJson(response, 200, { user });
}

function handleLogout(request, response) {
  const token = getBearerToken(request);

  if (token) {
    deleteSession.run(token);
  }

  sendJson(response, 200, { message: "Logged out." });
}

const server = createServer(async (request, response) => {
  response.setHeader("Access-Control-Allow-Origin", "*");

  if (request.method === "OPTIONS") {
    response.writeHead(204, {
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Origin": "*",
    });
    response.end();
    return;
  }

  try {
    const { pathname } = new URL(request.url, `http://${request.headers.host}`);

    if (request.method === "GET" && pathname === "/api/health") {
      sendJson(response, 200, { message: "API is running." });
      return;
    }

    if (request.method === "POST" && pathname === "/api/register") {
      await handleRegister(request, response);
      return;
    }

    if (request.method === "POST" && pathname === "/api/login") {
      await handleLogin(request, response);
      return;
    }

    if (request.method === "GET" && pathname === "/api/me") {
      handleMe(request, response);
      return;
    }

    if (request.method === "POST" && pathname === "/api/logout") {
      handleLogout(request, response);
      return;
    }

    sendJson(response, 404, { message: "Route not found." });
  } catch (error) {
    sendJson(response, 500, {
      message: error.message || "Something went wrong.",
    });
  }
});

server.listen(port, "127.0.0.1", () => {
  console.log(`Login API running at http://127.0.0.1:${port}`);
  console.log(`SQLite database: ${dbPath}`);
});
